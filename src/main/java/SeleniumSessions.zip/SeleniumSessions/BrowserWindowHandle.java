package SeleniumSessions;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserWindowHandle {

	public static void main(String[] args) throws InterruptedException {

		//browser window pop up/new tab window/new browser window
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/");//parent window
         Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@href='https://twitter.com/orangehrm?lang=en']")).click();
		//child window -- twitter page
		
		Set<String> handles = driver.getWindowHandles();// to get the window id we used "getWindowHandles" method
		// Set can't take the duplicate values but list can so we use Set here.
		//Set doesn't maintain index but ArrayList does
		// 
		
		Iterator<String> it = handles.iterator();// "itereator" is used to fetch the data in orderless collections and here Set is orderless 
		// it does not maintain index
		String parentWindowID = it.next();// we have to move our iterator to next for getting the parent window id
		System.out.println("parent window id is : " + parentWindowID);
		
		String childWindowId = it.next();
		System.out.println("child window id is : " + childWindowId);
		
		//switching:
		driver.switchTo().window(childWindowId);
		System.out.println("child window url : " + driver.getCurrentUrl());
		
		driver.close();//close the child window
		// now driver is lost so we have to move driver to parent window
		driver.switchTo().window(parentWindowID);
		System.out.println("parent window url : " + driver.getCurrentUrl());

		// People will ask you i don't want to use List not Set then how---see in next chapter
	}

}